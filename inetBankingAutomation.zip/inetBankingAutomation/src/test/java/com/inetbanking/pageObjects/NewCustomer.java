  package com.inetbanking.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class NewCustomer {
	WebDriver ldriver;

	public NewCustomer(WebDriver rdriver) {
		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

	@FindBy(how = How.XPATH, using = "//*[text()='New Customer']")
	WebElement NewCustomerLbl;

	@FindBy(how = How.XPATH, using = "//input[@onkeyup='validatecustomername();']")
	WebElement customerNam;

	@FindBy(how = How.XPATH, using = "//input[@type='radio']")
	WebElement radioButton;

	@FindBy(how = How.XPATH, using = "//textarea[@onkeyup='validateAddress();']")
	WebElement AddressField;

	@FindBy(how = How.XPATH, using = "//input[@onkeyup='validatedob();']")
	WebElement calender;
	@FindBy(how = How.XPATH, using = "//input[@name='city']")
	WebElement Xpathcity;
	@FindBy(how = How.XPATH, using = "//input[@name='state']")
	WebElement Xpathstate;
	@FindBy(how = How.XPATH, using = "//input[@name='pinno']")
	WebElement Xpathpin;
	@FindBy(how = How.XPATH, using = "//input[@name='telephoneno']")
	WebElement Xpathtelephone;
	@FindBy(how = How.XPATH, using = "//input[@name='emailid']")
	WebElement XpathEmail;
	@FindBy(how = How.XPATH, using = "//input[@name='password']")
	WebElement Xpathpassword;
	@FindBy(how = How.XPATH, using = "//input[@type='submit']")
	WebElement Xpathsubmit;

	public void NewCustomer() {
		NewCustomerLbl.click();
	}

	public void customerName(String customerName) {
		customerNam.sendKeys(customerName);
	}

	public void ClickOnRadioButton() {
		radioButton.click();
	}

	public void putAddress(String address) {
		AddressField.sendKeys(address);
	}

	public void calenderDate() {
		calender.sendKeys("25");
	}

	public void calendermonth() {
		calender.sendKeys("06");
	}

	public void calenderyear() {
		calender.sendKeys("1989");
	}

	public void setCity(String city) {
		Xpathcity.sendKeys(city);
	}
	
	public void setState(String state) {
		Xpathstate.sendKeys(state);
	}
	public void setPin(String pin) {
		Xpathpin.sendKeys(pin);
	}
	public void setTelephone(String telephone) {
		Xpathtelephone.sendKeys(telephone);
	}
	public void setEmail(String emailid) {
		XpathEmail.sendKeys(emailid);
	}
	public void setPassword(String password) {
		Xpathpassword.sendKeys(password);
	}
	public void clickSubmit() {
		Xpathsubmit.click();
	}
	
}
