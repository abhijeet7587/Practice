package com.inetbanking.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

public class ReadConfig {

	Properties pro;
	public ReadConfig() 
	{
		String projectpath=System.getProperty("user.dir");
		System.out.println(projectpath);
		File src=new File("./Configuration/config.properties");
		
		try {
			FileInputStream fis=new FileInputStream(src);
			pro=new Properties();
			pro.load(fis);
			
		}catch(Exception e) {
			System.out.println("exception"+e.getMessage());
		}
	}
	public String getApplicationURL() {
		String url=pro.getProperty("baseURL");
		return url;
		}
	public String getUsername() {
		String username=pro.getProperty("username");
		return username;
		}
	
	public String getLoginPassword() {
		String Loginpassword=pro.getProperty("Loginpassword");
		return Loginpassword;
		}
	
	public String getChromePath() {
		String chromePath=pro.getProperty("chromepath");
		return chromePath;
		
	}
	public String getFifefoxPath() {
		String firefoxpath=pro.getProperty("firefoxpath");
		return firefoxpath;
		
	}
	public String getCustomerName() {
		String customerName=pro.getProperty("customerName");
		return customerName;
		
	}
	public String getAddress() {
		String address=pro.getProperty("address");
		return address;
		
	}
	public String getcity() {
		String city=pro.getProperty("city");
		return city;
		
	}public String getstate() {
		String state=pro.getProperty("state");
		return state;
		
	}public String getpin() {
		String pin=pro.getProperty("pin");
		return pin;
		
	}public String getteleephone() {
		String telephone=pro.getProperty("telephone");
		return telephone;
		
	}public String getemailid() {
		String emailid=pro.getProperty("emailid");
		return emailid;
	}
	public String getpassword() {
		String password=pro.getProperty("password");
		return password;
		
	}
	
	
}
