package com.inetbanking.testCases;

import org.apache.commons.lang3.RandomStringUtils;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.inetbanking.pageObjects.LoginPage;
import com.inetbanking.pageObjects.NewCustomer;

public class TC_AddNewCustomerTest_002 extends BaseClass{
	@Test
	public void loginTest() throws Throwable {
	LoginPage lp = new LoginPage(driver);
    NewCustomer nc = new NewCustomer(driver);
	/* lp.login(username, password); */
	lp.setUserName(username);
	logger.info("Entered username");
	Thread.sleep(3000);
	lp.setpassword(Loginpassword);
	logger.info("Entered Password");
	Thread.sleep(3000);
	lp.clickSubmit();
	Thread.sleep(3000);
	logger.info("Login done");
	if (driver.getTitle().equals("Guru99 Bank Manager HomePage")) {
		Assert.assertTrue(true);
		logger.info("Login test passed");

	} else {
		Assert.assertTrue(false);
		logger.info("Login test failed");

	}
     nc.NewCustomer();
     nc.customerName(customerName);
     logger.info("entered Customer name successfully");
     nc.ClickOnRadioButton();
     logger.info("clicked on radio button  successfully");
     nc.putAddress(address);
     logger.info("entered address successfully");
     nc.calenderDate();
     nc.calendermonth();
     nc.calenderyear();
     nc.setCity(city);
     nc.setState(state);
     nc.setTelephone(telephone);
     nc.setPin(pin);
     String emailid=randomeString()+"@yahoo.com";
     nc.setEmail(emailid);
     nc.setPassword(epassword);
     nc.clickSubmit();
     logger.info("successfully i did the requirement utomation");
  boolean res=driver.getPageSource().contains("Customer Registered Successfully!!!");
    if(res==true) 
    {
    	Assert.assertTrue(true);
    	  logger.info("addition of new customer done successfully");
    	
    }
    else
    {
    	Assert.assertTrue(true);
    	logger.info("addition of new customer failed");
    }
     
}
	 public String  randomeString()
     {
		 String generatedtring=RandomStringUtils.randomAlphabetic(10);
		return (generatedtring);
    	 
     }
     
}
