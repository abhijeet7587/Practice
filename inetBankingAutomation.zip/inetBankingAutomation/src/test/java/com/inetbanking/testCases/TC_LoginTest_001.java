package com.inetbanking.testCases;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.inetbanking.pageObjects.LoginPage;
import com.inetbanking.pageObjects.NewCustomer;

public class TC_LoginTest_001 extends BaseClass {

	@Test
	public void loginTest() throws Throwable {

		LoginPage lp = new LoginPage(driver);
        NewCustomer nc = new NewCustomer(driver);
		/* lp.login(username, password); */
		lp.setUserName(username);
		logger.info("Entered username");
		Thread.sleep(3000);
		lp.setpassword(Loginpassword);
		logger.info("Entered Password");
		Thread.sleep(3000);
		lp.clickSubmit();
		Thread.sleep(3000);
		logger.info("Login done");
		if (driver.getTitle().equals("Guru99 Bank Manager HomePage")) {
			Assert.assertTrue(true);
			logger.info("Login test passed");

		} else {
			Assert.assertTrue(false);
			logger.info("Login test failed");

		}
//	
	}

}